
var __name__ = "__main__";

alert("alert");
blurt("blurt");