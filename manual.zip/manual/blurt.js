
var __name__ = "__main__";

function blurt(s) {
    alert(s);
};
if (!blurt.__argnames__) Object.defineProperties(blurt, {
    __argnames__ : {value: ["s"]}
});
