import threading, time
#inspired by https://automatetheboringstuff.com/chapter15/
print('trigger2 in GlowPy')

def trigger(what, every=1):
       time.sleep(every)
       what()

       threadObj = threading.Thread(target=trigger, args=[what, every])
       threadObj.start()
       
       
def do(what, howOften='in', interval=0, firstTime=True,times='forever'):
    threadObj=None #to unBoundLocal error
    if firstTime: #cue it up, but don't do it
        if type(time)==type(2): times+=1 #just to make it count right
        threadObj = threading.Thread(target=do, args=[what, howOften, interval, False, times])
        threadObj.start()

    else:
        #print('.', end='')
        time.sleep(interval) #we are here via the thread object, so this sleep should not block
        if type(times)==type(2):
            times-=1
        if times: #if >0 or 'forever'
            if howOften == 'every': #set up the next one.  TODO A stop flag would be cool. 
                threadObj = threading.Thread(target=do, args=[what, howOften, interval, False, times])
                threadObj.start()
            what() #now do it

def interval(ping, delayInMsecs, times='forever'): #this emulates
    #https://www.thecodeship.com/web-development/alternative-to-javascript-evil-setinterval/  
    do(ping, 'every', delayInMsecs/1000, times=times)
    
if __name__=='__main__':
    def ping():
        print('# ',end='')
        
    def pong():
        print('o ',end='')
        
    def once():
        print('!!', end='')
        
    def R():
        print()
    

    interval(pong, 300, 15)
    interval(ping, 100, 15)
    do(once, 'in', 1) #once the unit is
    do(R, 'every', interval=0.3, times=5)
    print('----')
