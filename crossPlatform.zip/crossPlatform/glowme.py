from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.action_chains import ActionChains

from copypaste import write_to_clipboard, read_from_clipboard
from time import sleep
import sys
B=webdriver.Firefox()
trace=1
  
def srcFromFileName(filename='test.py'):
    """get source, apply transformation"""
    if trace: print('srcFromFileName',filename)

    thesource=open(filename).read()
    
    lines= thesource.split('\n')
    
    firstLine = 'GlowScript 2.7 VPython'
    if lines[0] != firstLine:
        lines.insert(0, firstLine )
        
    lines.insert(1, 'def GlowMe( me=""):\n\tpass')
    lines.insert(2, "get_library('http://localhost:8080/lib/jonlib.js')")
    fixedLines=[]
    for line in lines:
        
        toxicStarters = 'GlowMe from import DICT=dict'.split()
        for poison in toxicStarters:
            if line.strip().startswith(poison):
                line='##GlowMe    '+line
                print(line)                
        fixedLines.append(line)
            
    return '\n'.join(fixedLines)


def send(fileName, thesource):
    global textArea
    if trace: print('send source')
    global B, B2
    #B.get('http://localhost:8080/#/user/jschull/folder/Public/program/'+fileName + '/edit')
    #B.refresh()
    #B.get('http://localhost:8080/#/user/jschull/folder/Public/program/test.py/edit')
    #body=B.find_element_by_tag_name('body')
    #body.send_keys(Keys.COMMAND+"a")


    """put src into clipboard,and paste into B.rowser """

    #selectall and then paste over it
    sleep(1)
    textArea=B.find_element_by_tag_name('textarea')
    sleep(1)
    textArea.send_keys(Keys.COMMAND+"a")
    sleep(1)
    textArea.send_keys(Keys.BACKSPACE)
    #print('backspace')
    sleep(1)
    write_to_clipboard(thesource)
    sleep(1)
    textArea=B.find_element_by_tag_name('textarea')
    textArea.send_keys(Keys.COMMAND+"v")  #PASTE from clipbaord
    sleep(2) #allow time for change to get back to server
    return(thesource)

def myFileName():
    return sys.argv[0]

def login():
    global input
    if trace: print('login')
    B.get('http://localhost:8080')
    sleep(0.5)
    B.find_element_by_link_text('Sign in').click()
    input=B.find_element_by_tag_name('input')
    input.click()
    input.send_keys(Keys.RIGHT * 20)
    input.send_keys(Keys.BACKSPACE * 20)
    input.send_keys('jschull@gmail.com')
    input.send_keys(Keys.TAB*2)
    input.send_keys(Keys.RETURN)

##    input.send_keys(Keys.COMMAND+"a")
##    input.send_keys('jschull@gmail.com')
##    B.find_element_by_id('submit-login').click()
    B.get('http://localhost:8080/#/user/jschull/folder/Public/')
    sleep(0.2)
    B.find_element_by_link_text('Create New Program').click()

def createFile(fileName):
    if trace: print('createFile', fileName)
    actions = ActionChains(B)
    actions.send_keys(fileName).send_keys(Keys.ENTER).perform()



def makeJS(fileName):
    if trace: print('makeJS',fileName)
    B.get('http://localhost:8080/#/user/jschull/folder/Public/program/'+fileName+'/share')
    f=open( fileName+'.js' ,'w')
    sleep(1)
    t=B.find_element_by_tag_name('textarea').text
    sleep(1)
    t= t.split('<![CDATA[//><!--')[1]
    #the good stuff is between these
    t= t.split('//--><!]]>')[0]
    f.write(t)
    f.close()
    print('GlowMe created:  ' + fileName + '.js')
    return t
    
##    #    <link href="https://fonts.googleapis.com/css?family=Inconsolata" rel="stylesheet" type="text/css" />

def makeHTML(fileName):
    if trace: print('makeHTML',fileName)
    makeJS(fileName)
    template="""
    <div id="glowscript" class="glowscript">
    <link type="text/css" href="http://localhost:8080/css/redmond/jquery-ui.custom.css" rel="stylesheet" />
    <link type="text/css" href="http://localhost:8080/css/ide.css" rel="stylesheet" />

    <script type="text/javascript" language="javascript" src="http://localhost:8080/lib/jquery/IDE/jquery.min.js"></script>
    <script type="text/javascript" language="javascript" src="http://localhost:8080/lib/jquery/IDE/jquery-ui.custom.min.js"></script>
    <script type="text/javascript"                       src="http://localhost:8080/package/glow.2.7.min.js"></script>
    <script type="text/javascript"                       src="http://localhost:8080/package/RSrun.2.7.min.js"></script>
    

    <script type="text/javascript" src="test.py.js"></script>

    </div>""".replace('test.py.js', fileName + '.js')
    fname=fileName + '.js.html'
    f=open(fname,'w')
    f.write(template)
    f.close()
    print('GlowMe created:  ' + fileName + '.js.html')
    return template

def positionWindows(fileName):
    if trace: print('positionWindow',fileName)
    global B, B2
    B2=webdriver.Chrome()
    B.get('http://localhost:8080/#/user/jschull/folder/Public/program/'+fileName)
    B.maximize_window()
    screen = B.get_window_size()
    width  = screen['width']
    height = screen['height']
    B.set_window_rect(0,0,round(width/2), round(height/2))
    sleep(1)
    B2.set_window_rect(0,round(height/2), round(width/2), round(height/2))
    sleep(1)
    
    import os
    
    B2.get('file://' + os.getcwd() + '/' + fileName + '.js.html')
    sleep(1)
 
def closem():
    B.close()
    B2.close()


def GlowMe(fileName):
    print('GlowMe', fileName)
    global B, B2
    
    login()
    createFile(fileName) 
    
    thesource = srcFromFileName(fileName)
    send(fileName, thesource)
    print('==========over here')

    sleep(1)
    textArea=B.find_element_by_tag_name('textarea')
    textArea.send_keys(Keys.CONTROL+"1")
    sleep(1)
    
    makeHTML(fileName)
    positionWindows(fileName)

fileName='test.py'


if __name__=='__main__':
    print("""
When imported, GlowMe munges the program that does the importing.
When testing, i.e., when __name__=='__main___', GlowMe munges test.py (which needs to exist).
""")
    testfileName='test.py'
else:
    testfileName= myFileName()
    
GlowMe(testfileName)
    
