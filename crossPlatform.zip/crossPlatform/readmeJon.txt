This directory is for things that are tested and working.

The goals is a cross-platform glowscript/python development system.
* local development in python (I use thonny but these programs do run from the commandline).
* local development in glowscript (see installing glowscript below)

Preliminaries
    
    * to run the glowscript server you need an update version of python2.7 and you need to to install gcloud (akaa google app engine)
    
    update python update python2 
        (I downloaded and installed from python.org)
    
    install gcloud. This may suffice (not fully tested):
        pip install --upgrade gcloud
    
    
    Installing glowscript
    * create and enter a directory under your home directory
    change directory to home directory:
        cd
    create directory:
        mkdir glowscript
    enter that directory:
        cd glowscript
    clone the source code from https://github.com/BruceSherwood/glowscript.git
        git clone https://github.com/BruceSherwood/glowscript.git
    change into the glowscript directory that contains app.yaml. it's probably in ~/glowscript/glowscript but you can use cd ls to list contents and check
      cd glowscript
      ls 
    
    now you bring them together:  You have dev_appserver.py process app.yaml:
        dev_appserver.py app.yaml
    
    If all went well, you'll see something like this:
        INFO     2018-02-25 22:13:18,005 devappserver2.py:105] Skipping SDK update check.
        INFO     2018-02-25 22:13:18,083 api_server.py:308] Starting API server at: http://localhost:58531
        INFO     2018-02-25 22:13:18,186 dispatcher.py:255] Starting module "default" running at: http://localhost:8080
        INFO     2018-02-25 22:13:18,190 admin_server.py:146] Starting admin server at: http://localhost:8000
        
    Glowscript is running.  Point your browser to http://localhost:8000 
    Learn some vpython
    
    
Whereas dev-appserver.py needs python 2, vpython needs python3.  I suggest you just download and use a self-contained editor and development environment called Thonny.
    
To use my system you need to put the file script called jonlib.js into the glowscript/lib directory.  [TO DO: THIS SHOULD BE DONE AUTOMAGICALLY]
    
    install my system in its own directory
        cd
        mkdir light
        cd light
        git clone https://github.com/jonschull/glowscript.git
        
Use thonny to open vpythonTest.py
    a browser should pop up, and     you should see a spinning yellow cube
    if you ask Thonny to stop the program interrupt, the cube stops spining.
    That's because dynamice vpython activity relies on the python3 engine.
    Also, the interval function is not available in vpython out-of-the box.
    
Now here's the point.  

    Python is a mature language with good error messages, and great power.  But doesn't run in the browser.
    
    Glowscript is an elegant subset of python that uses Rapydscript (don't ask) to run on the javascript engine that is built right into your web browser.  Glowscript programs that use only the magic python subset can be embedded into HTML web pages and they will just work.  
    
    With the light system, you can develop and test such program in python (fast iterative development), AND in the Glowscript IDE, AND  in a standalone HTML page.
    
    To see this in action, add append a line to vpythonTest.py:
       import glowme
    Run your program again.  You should see three renditions of your program:
        1.  the vpython version
        2.  a version running in the Glowscript IDE
        3.  a version running in a standalone webpage 
        
To make this work, I'm developing several utilities to address several shortcomings

    * an interval function makes for help with things like spinning cubes 
        (interval included in jonlib.js)
    
    * a DICT data structure that 
        ** works similarly in both GlowScript and Python
        ** is easy to inspect 
        ** returns keys and values as lists (as in py2 for easy inspection and manipulation)
    
    * glowme modules uses the local glowscript server to compile, test, and export your program into a standalone html page
    
    * cross platform import scheme that allows you to modularize your code
        ** we use import on python
        ** we use get_library in glowscript 
        ** if we use them together, modules written and imported in python will automagically be available via get_library in glowscript.  [NOT DONE YET]
    
    
    
    

    

    
    
    