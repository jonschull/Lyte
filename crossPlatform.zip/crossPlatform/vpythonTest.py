from vpython import *
from time import sleep
from trigger2 import interval

scene=canvas()

b=box()
l=label()
l.text='sunday 2-28-5:45'
b.color=color.yellow

def spin():
    b.rotate(angle=0.1, axis=vector(0,1,0))
    
interval(spin, 50)
print(l.text)

import glowme