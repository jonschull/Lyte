
;(function() { var __rt=srequire('streamline/lib/callbacks/runtime').runtime(__filename, false),__func=__rt.__func,__cb=__rt.__cb; var RS_modules = {};
var spheres, labels, curves, twoferDict;
RS_modules.pythonize = {};

(function() {
  function strings() {
    var string_funcs, exclude, name;
    string_funcs = set("capitalize strip lstrip rstrip islower isupper isspace lower upper swapcase center count endswith startswith find rfind index rindex format join ljust rjust partition rpartition replace split rsplit splitlines zfill".split(" "));
    if (!arguments.length) {
      exclude = (function() {
        var s = RS_set();
        s.jsset.add("split");
        s.jsset.add("replace");
        return s;
      })(); }
     else if (arguments[0]) {
      exclude = Array.prototype.slice.call(arguments); }
     else {
      exclude = null; }  ;

    if (exclude) {
      string_funcs = string_funcs.difference(set(exclude)); } ;

    var RS_Iter0 = RS_Iterable(string_funcs);
    for (var RS_Index0 = 0; RS_Index0["<"](RS_Iter0.length); RS_Index0++) {
      name = RS_Iter0[RS_Index0];
      (RS_expr_temp = String.prototype)[((((typeof name === "number") && name["<"](0))) ? RS_expr_temp.length["+"](name) : name)] = (RS_expr_temp = RS_str.prototype)[((((typeof name === "number") && name["<"](0))) ? RS_expr_temp.length["+"](name) : name)]; }; };  RS_modules.pythonize.strings = strings;
})();
function main(_) { var version, box, sphere, cylinder, pyramid, cone, helix, ellipsoid, ring, arrow, compound, display, vector, print, scene, RS_ls, V, data, edges, spheres, labels, twoferDict, curves, nodes, s, l, node, RS_unpack, t, spos, tpos, edge, __name__, strings, RS_Iter19, RS_Index19, RS_Iter20, RS_Index20, __this = this;
  function GlowMe() {
    var me = ((((arguments[0] === undefined) || (((((0 === arguments.length["-"](1)) && (arguments[arguments.length["-"](1)] !== null)) && (typeof arguments[arguments.length["-"](1)] === "object")) && (arguments[arguments.length["-"](1)][RS_kwargs_symbol] === true))))) ? GlowMe.__defaults__.me : arguments[0]);
    var RS_kwargs_obj = arguments[arguments.length["-"](1)];
    if ((((RS_kwargs_obj === null) || (typeof RS_kwargs_obj !== "object")) || (RS_kwargs_obj[RS_kwargs_symbol] !== true))) { RS_kwargs_obj = { }; };
    if (Object.prototype.hasOwnProperty.call(RS_kwargs_obj, "me")) {
      me = RS_kwargs_obj.me; } ;

    var RS_ls;
    "3"; };


  function DICT() {
    if ((this.RS_object_id === undefined)) { Object.defineProperty(this, "RS_object_id", { value: ++RS_object_counter }); };
    DICT.prototype.__init__.apply(this, arguments); };  function _hooke(n1, n2, k, r) {
    var RS_ls, delta, RS_unpack, x1, x2, distance, i, force;
    "70Calculates Hooke spring forces and updates node data.";
    "74";
    delta = (function() {
      var RS_Iter = RS_Iterable(zip(RS_getitem(n1, "velocity"), RS_getitem(n2, "velocity"))), RS_Result = [], x1, x2;
      for (var RS_Index = 0; RS_Index["<"](RS_Iter.length); RS_Index++) {
        RS_unpack = RS_Iter[RS_Index];
        x1 = RS_unpack[0];
        x2 = RS_unpack[1];
        RS_Result.push(x2["-"](x1)); };

      RS_Result = RS_list_constructor(RS_Result);
      return RS_Result;
    })();
    "77";
    distance = sqrt(sum((function() {
      var RS_Iter = RS_Iterable(delta), RS_Result = [], d;
      for (var RS_Index = 0; RS_Index["<"](RS_Iter.length); RS_Index++) {
        d = RS_Iter[RS_Index];
        RS_Result.push(GS_power(d, 2)); };

      RS_Result = RS_list_constructor(RS_Result);
      return RS_Result;
    })()));
    "80";
    if (distance["<"](0.1)) {
      "81";
      delta = (function() {
        var RS_Iter = RS_Iterable(range(3)), RS_Result = [], i;
        for (var RS_Index = 0; RS_Index["<"](RS_Iter.length); RS_Index++) {
          i = RS_Iter[RS_Index];
          RS_Result.push(0.1["+"](random()["*"](0.1))); };

        RS_Result = RS_list_constructor(RS_Result);
        return RS_Result;
      })();
      "82";
      distance = sqrt(sum((function() {
        var RS_Iter = RS_Iterable(delta), RS_Result = [], d;
        for (var RS_Index = 0; RS_Index["<"](RS_Iter.length); RS_Index++) {
          d = RS_Iter[RS_Index];
          RS_Result.push(GS_power(d, 2)); };

        RS_Result = RS_list_constructor(RS_Result);
        return RS_Result;
      })())); } ;

    "85";
    distance = min(distance, r);
    "88";
    force = GS_power(distance, 2)["-"](GS_power(k, 2))["/"](distance["*"](k));
    "89";
    RS_setitem(n1, "force", (function() {
      var RS_Iter = RS_Iterable(zip(RS_getitem(n1, "force"), delta)), RS_Result = [], f, d;
      for (var RS_Index = 0; RS_Index["<"](RS_Iter.length); RS_Index++) {
        RS_unpack = RS_Iter[RS_Index];
        f = RS_unpack[0];
        d = RS_unpack[1];
        RS_Result.push(f["+"](force["*"](d))); };

      RS_Result = RS_list_constructor(RS_Result);
      return RS_Result;
    })());
    "90";
    RS_setitem(n2, "force", (function() {
      var RS_Iter = RS_Iterable(zip(RS_getitem(n2, "force"), delta)), RS_Result = [], f, d;
      for (var RS_Index = 0; RS_Index["<"](RS_Iter.length); RS_Index++) {
        RS_unpack = RS_Iter[RS_Index];
        f = RS_unpack[0];
        d = RS_unpack[1];
        RS_Result.push(f["-"](force["*"](d))); };

      RS_Result = RS_list_constructor(RS_Result);
      return RS_Result;
    })()); };


  function _constrain(value, min_value, max_value) {
    var RS_ls;
    "93--Constrains a value to the inputted range--.";
    "94";
    return max(min_value, min(value, max_value)); };


  function vFromLoc(loc) {
    var RS_ls, RS_unpack, x, y, z;
    "98";
    if (len(loc)["<"](3)) {
      "99";
      loc.append(0); } ;

    "100";
    RS_unpack = loc;
    RS_unpack = RS_unpack_asarray(3, RS_unpack);
    x = RS_unpack[0];
    y = RS_unpack[1];
    z = RS_unpack[2];
    "101";
    return vector(x, y, z); };


  function nodesFromEdges(edges) {
    var RS_ls, nodes, RS_unpack, s, t, node, edge;
    "104";
    nodes = RS_list_decorate([]);
    "105";
    var RS_Iter6 = RS_Iterable(edges);
    for (var RS_Index6 = 0; RS_Index6["<"](RS_Iter6.length); RS_Index6++) {
      edge = RS_Iter6[RS_Index6];
      "106";
      RS_unpack = edge;
      RS_unpack = RS_unpack_asarray(2, RS_unpack);
      s = RS_unpack[0];
      t = RS_unpack[1];
      "107";
      var RS_Iter7 = RS_Iterable(RS_list_decorate([s,t,]));
      for (var RS_Index7 = 0; RS_Index7["<"](RS_Iter7.length); RS_Index7++) {
        node = RS_Iter7[RS_Index7];
        "108";
        if (!(RS_in(node, nodes))) {
          "109";
          nodes.append(node); } ; }; };    "110";
    return nodes; };


  function generate(edges, _) { var RS_ls, iterations, force_strength, dampening, max_velocity, max_distance, is_3d, nodeIDs, nodeID, edge, d, nodes, r, k, delta, RS_unpack, x1, x2, ddd, distance, i, force, node1, node2, s, t, f, ID, node, c, RS_Iter8, RS_Index8, RS_Iter9, RS_Index9, RS_Iter10, RS_Index10, RS_Index13, RS_Iter14, RS_Index14, RS_Iter15, RS_Index15, RS_Iter16, RS_Index16, RS_Iter17, RS_Index17, RS_Iter18, RS_Index18, __this = this;
    function combinations() {
      var iter = ((((arguments[0] === undefined) || (((((0 === arguments.length["-"](1)) && (arguments[arguments.length["-"](1)] !== null)) && (typeof arguments[arguments.length["-"](1)] === "object")) && (arguments[arguments.length["-"](1)][RS_kwargs_symbol] === true))))) ? combinations.__defaults__.iter : arguments[0]);
      var len = ((((arguments[1] === undefined) || (((((1 === arguments.length["-"](1)) && (arguments[arguments.length["-"](1)] !== null)) && (typeof arguments[arguments.length["-"](1)] === "object")) && (arguments[arguments.length["-"](1)][RS_kwargs_symbol] === true))))) ? combinations.__defaults__.len : arguments[1]);
      var RS_kwargs_obj = arguments[arguments.length["-"](1)];
      if ((((RS_kwargs_obj === null) || (typeof RS_kwargs_obj !== "object")) || (RS_kwargs_obj[RS_kwargs_symbol] !== true))) { RS_kwargs_obj = { }; };
      if (Object.prototype.hasOwnProperty.call(RS_kwargs_obj, "iter")) {
        iter = RS_kwargs_obj.iter; } ;

      if (Object.prototype.hasOwnProperty.call(RS_kwargs_obj, "len")) {
        len = RS_kwargs_obj.len; } ;

      var RS_ls, combos, j, i;
      "145";
      combos = RS_list_decorate([]);
      "146";
      var RS_Iter11 = RS_Iterable(iter);
      for (var RS_Index11 = 0; RS_Index11["<"](RS_Iter11.length); RS_Index11++) {
        i = RS_Iter11[RS_Index11];
        "147";
        var RS_Iter12 = RS_Iterable(iter);
        for (var RS_Index12 = 0; RS_Index12["<"](RS_Iter12.length); RS_Index12++) {
          j = RS_Iter12[RS_Index12];
          "148";
          if ((((i !== j) && (((typeof i !== "object") || RS_not_equals(i, j)))))) {
            "149";
            if (!(RS_in([i,j,], combos))) {
              "150";
              if (!(RS_in([j,i,], combos))) {
                "151";
                combos.append([i,j,]); } ; } ; } ; }; };

      "152";
      return combos; }; var __frame = { name: "generate", line: 393 }; return __func(_, this, arguments, generate, 1, __frame, function __$generate() { "114"; iterations = 1000; "115"; force_strength = 5; "116"; dampening = 0.01; "117"; max_velocity = 2; "118"; max_distance = 50; "119"; is_3d = false; "125"; "130"; nodeIDs = RS_list_decorate([]); "131"; RS_Iter8 = RS_Iterable(edges); for (RS_Index8 = 0; RS_Index8["<"](RS_Iter8.length); RS_Index8++) { edge = RS_Iter8[RS_Index8]; "132"; RS_Iter9 = RS_Iterable(edge); for (RS_Index9 = 0; RS_Index9["<"](RS_Iter9.length); RS_Index9++) { nodeID = RS_Iter9[RS_Index9]; "133"; if (!(RS_in(nodeID, nodeIDs))) { "134"; nodeIDs.append(nodeID); } ; }; }; "137"; d = ((is_3d) ? 3 : 2); "139"; nodes = new DICT; "140"; RS_Iter10 = RS_Iterable(nodeIDs); RS_Index10 = 0; var __12 = false; return (function ___(__break) { var __more; var __loop = __cb(_, __frame, 0, 0, function __$generate() { __more = false; if (__12) { RS_Index10++; } else { __12 = true; } ; var __11 = RS_Index10["<"](RS_Iter10.length); if (__11) { nodeID = RS_Iter10[RS_Index10]; "141"; return (function ___closure(_) { var RS_d; RS_d = RS_dict(); RS_d.set("velocity", RS_list_decorate([0,])["*"](d)); RS_d.set("force", RS_list_decorate([0,])["*"](d)); return _(null, RS_d); })(__cb(_, __frame, 41, 122, function ___(__0, __1) { RS_setitem(nodes, nodeID, RS_interpolate_kwargs_constructor.call(Object.create(DICT.prototype), false, DICT, [__1,].concat([RS_desugar_kwargs({ ID: nodeID }),]))); while (__more) { __loop(); }; __more = true; }, true)); } else { __break(); } ; }); do { __loop(); } while (__more); __more = true; })(function __$generate() { "144";

        if (!combinations.__defaults__) { Object.defineProperties(combinations, {
            __defaults__: { value: { iter: "ABCD", len: 2 } },
            __handles_kwarg_interpolation__: { value: true },
            __argnames__: { value: ["iter","len",] } }); } ;


        "155";
        RS_Index13 = 0; var __15 = false; return (function ___(__break) { var __more; var __loop = __cb(_, __frame, 0, 0, function __$generate() { __more = false; if (__15) { RS_Index13++; } else { __15 = true; } ; var __14 = RS_Index13["<"](iterations); if (__14) {
              i = RS_Index13;
              "158";
              RS_Iter14 = RS_Iterable(combinations(nodes.values(), 2));
              RS_Index14 = 0; var __17 = false; return (function ___(__break) { var __more; var __loop = __cb(_, __frame, 0, 0, function __$generate() { __more = false; if (__17) { RS_Index14++; } else { __17 = true; } ; var __16 = RS_Index14["<"](RS_Iter14.length); if (__16) {
                    RS_unpack = RS_Iter14[RS_Index14];
                    node1 = RS_unpack[0];
                    node2 = RS_unpack[1];
                    "159";
                    r = max_distance;
                    "160";
                    k = force_strength;
                    "161";


                    return (function ___closure(_) { var RS_Iter, RS_Result, x1, x2, RS_Index; RS_Iter = RS_Iterable(zip(RS_getitem(node1, "velocity"), RS_getitem(node2, "velocity"))); RS_Result = []; for (RS_Index = 0; RS_Index["<"](RS_Iter.length); RS_Index++) { RS_unpack = RS_Iter[RS_Index]; x1 = RS_unpack[0]; x2 = RS_unpack[1]; RS_Result.push(x2["-"](x1)); }; RS_Result = RS_list_constructor(RS_Result); return _(null, RS_Result); })(__cb(_, __frame, 107, 24, function ___(__0, __2) { delta = __2;
                      "162";
                      return (function ___closure(_) { var RS_Iter, RS_Result, d, RS_Index; RS_Iter = RS_Iterable(delta); RS_Result = []; for (RS_Index = 0; RS_Index["<"](RS_Iter.length); RS_Index++) { d = RS_Iter[RS_Index]; RS_Result.push(GS_power(d, 2)); }; RS_Result = RS_list_constructor(RS_Result); return _(null, RS_Result); })(__cb(_, __frame, 119, 26, function ___(__0, __3) { ddd = sum(__3);
                        "163";
                        distance = sqrt(ddd);
                        "166"; return (function __$generate(__then) {
                          if (distance["<"](0.1)) {
                            "167";
                            return (function ___closure(_) { var RS_Iter, RS_Result, i, RS_Index; RS_Iter = RS_Iterable(range(3)); RS_Result = []; for (RS_Index = 0; RS_Index["<"](RS_Iter.length); RS_Index++) { i = RS_Iter[RS_Index]; RS_Result.push(0.1["+"](0.2["-"](0.1)["*"](random()))); }; RS_Result = RS_list_constructor(RS_Result); return _(null, RS_Result); })(__cb(_, __frame, 133, 28, function ___(__0, __4) { delta = __4;
                              "168";
                              return (function ___closure(_) { var RS_Iter, RS_Result, d, RS_Index; RS_Iter = RS_Iterable(delta); RS_Result = []; for (RS_Index = 0; RS_Index["<"](RS_Iter.length); RS_Index++) { d = RS_Iter[RS_Index]; RS_Result.push(GS_power(d, 2)); }; RS_Result = RS_list_constructor(RS_Result); return _(null, RS_Result); })(__cb(_, __frame, 143, 26, function ___(__0, __5) { ddd = __5;
                                "169";
                                distance = sqrt(sum(ddd)); __then(); }, true)); }, true)); } else { __then(); } ; })(function __$generate() {

                          "173"; return (function __$generate(__then) {
                            if (distance["<"](r)) {
                              "174";
                              force = GS_power((k["/"](distance)), 2);
                              "175";


                              return (function ___closure(_) { var RS_Iter, RS_Result, f, d, RS_Index; RS_Iter = RS_Iterable(zip(RS_getitem(node1, "force"), delta)); RS_Result = []; for (RS_Index = 0; RS_Index["<"](RS_Iter.length); RS_Index++) { RS_unpack = RS_Iter[RS_Index]; f = RS_unpack[0]; d = RS_unpack[1]; RS_Result.push(f["-"](force["*"](d))); }; RS_Result = RS_list_constructor(RS_Result); return _(null, RS_Result); })(__cb(_, __frame, 160, 47, function ___(__0, __6) { RS_setitem(node1, "force", __6);
                                "176";


                                return (function ___closure(_) { var RS_Iter, RS_Result, f, d, RS_Index; RS_Iter = RS_Iterable(zip(RS_getitem(node2, "force"), delta)); RS_Result = []; for (RS_Index = 0; RS_Index["<"](RS_Iter.length); RS_Index++) { RS_unpack = RS_Iter[RS_Index]; f = RS_unpack[0]; d = RS_unpack[1]; RS_Result.push(f["+"](force["*"](d))); }; RS_Result = RS_list_constructor(RS_Result); return _(null, RS_Result); })(__cb(_, __frame, 172, 47, function ___(__0, __7) { RS_setitem(node2, "force", __7); __then(); }, true)); }, true)); } else { __then(); } ; })(function __$generate() { while (__more) { __loop(); }; __more = true; }); }); }, true)); }, true)); } else { __break(); } ; }); do { __loop(); } while (__more); __more = true; })(function __$generate() {


                "178";
                RS_Iter15 = RS_Iterable(edges);
                for (RS_Index15 = 0; RS_Index15["<"](RS_Iter15.length); RS_Index15++) {
                  edge = RS_Iter15[RS_Index15];
                  "180";
                  RS_unpack = edge;
                  RS_unpack = RS_unpack_asarray(2, RS_unpack);
                  s = RS_unpack[0];
                  t = RS_unpack[1];
                  "181";
                  _hooke(RS_getitem(nodes, s), RS_getitem(nodes, t), force_strength, max_distance); };

                "186";
                RS_Iter16 = RS_Iterable(nodes.values());
                RS_Index16 = 0; var __25 = false; return (function ___(__break) { var __more; var __loop = __cb(_, __frame, 0, 0, function __$generate() { __more = false; if (__25) { RS_Index16++; } else { __25 = true; } ; var __24 = RS_Index16["<"](RS_Iter16.length); if (__24) {
                      node = RS_Iter16[RS_Index16];
                      "188";
                      return (function ___closure(_) { var RS_Iter, RS_Result, f, RS_Index; RS_Iter = RS_Iterable(RS_getitem(node, "force")); RS_Result = []; for (RS_Index = 0; RS_Index["<"](RS_Iter.length); RS_Index++) { f = RS_Iter[RS_Index]; RS_Result.push(_constrain(dampening["*"](f), max_velocity["-u"](), max_velocity)); }; RS_Result = RS_list_constructor(RS_Result); return _(null, RS_Result); })(__cb(_, __frame, 202, 24, function ___(__0, __8) { force = __8;
                        "191";


                        return (function ___closure(_) { var RS_Iter, RS_Result, v, dv, RS_Index; RS_Iter = RS_Iterable(zip(RS_getitem(node, "velocity"), force)); RS_Result = []; for (RS_Index = 0; RS_Index["<"](RS_Iter.length); RS_Index++) { RS_unpack = RS_Iter[RS_Index]; v = RS_unpack[0]; dv = RS_unpack[1]; RS_Result.push(v["+"](dv)); }; RS_Result = RS_list_constructor(RS_Result); return _(null, RS_Result); })(__cb(_, __frame, 212, 45, function ___(__0, __9) { RS_setitem(node, "velocity", __9);
                          "194";
                          ID = RS_getitem(node, "ID");
                          "195";
                          RS_getitem(spheres, ID).pos = vFromLoc(RS_getitem(node, "velocity"));
                          "196";
                          RS_getitem(labels, ID).pos = RS_getitem(spheres, ID).pos;
                          "197";
                          RS_setitem(node, "force", RS_list_decorate([0,])["*"](d));
                          "198";
                          return rate(800, __cb(_, __frame, 232, 16, function __$generate() { while (__more) { __loop(); }; __more = true; }, true)); }, true)); }, true)); } else { __break(); } ; }); do { __loop(); } while (__more); __more = true; })(function __$generate() {

                  "200";
                  RS_Iter17 = RS_Iterable(edges);
                  for (RS_Index17 = 0; RS_Index17["<"](RS_Iter17.length); RS_Index17++) {
                    edge = RS_Iter17[RS_Index17];
                    "201";
                    RS_unpack = edge;
                    RS_unpack = RS_unpack_asarray(2, RS_unpack);
                    s = RS_unpack[0];
                    t = RS_unpack[1];
                    "202";
                    c = curves(s, t);
                    "203";
                    c.clear();
                    "204";
                    c.append(RS_list_decorate([RS_getitem(spheres, s).pos,RS_getitem(spheres, t).pos,])); }; while (__more) { __loop(); }; __more = true; }); }); } else { __break(); } ; }); do { __loop(); } while (__more); __more = true; })(function __$generate() {


          "209";
          RS_Iter18 = RS_Iterable(nodes.values());
          for (RS_Index18 = 0; RS_Index18["<"](RS_Iter18.length); RS_Index18++) {
            node = RS_Iter18[RS_Index18];
            "210";
            RS_delitem(node, "force");
            "211";
            RS_setitem(node, "location", RS_getitem(node, "velocity"));
            "212";
            RS_delitem(node, "velocity");
            "214";
            if (!is_3d) {
              "215";
              RS_getitem(node, "location").append(0); } ; };


          "219";

          return (function ___closure(_) { var RS_d; RS_d = RS_dict(); RS_d.set("edges", edges); RS_d.set("nodes", nodes); return _(null, RS_d); })(__cb(_, __frame, 268, 15, _, true)); }); }); }); };


  function twofer() {
    var x = ((((arguments[0] === undefined) || (((((0 === arguments.length["-"](1)) && (arguments[arguments.length["-"](1)] !== null)) && (typeof arguments[arguments.length["-"](1)] === "object")) && (arguments[arguments.length["-"](1)][RS_kwargs_symbol] === true))))) ? twofer.__defaults__.x : arguments[0]);
    var y = ((((arguments[1] === undefined) || (((((1 === arguments.length["-"](1)) && (arguments[arguments.length["-"](1)] !== null)) && (typeof arguments[arguments.length["-"](1)] === "object")) && (arguments[arguments.length["-"](1)][RS_kwargs_symbol] === true))))) ? twofer.__defaults__.y : arguments[1]);
    var z = ((((arguments[2] === undefined) || (((((2 === arguments.length["-"](1)) && (arguments[arguments.length["-"](1)] !== null)) && (typeof arguments[arguments.length["-"](1)] === "object")) && (arguments[arguments.length["-"](1)][RS_kwargs_symbol] === true))))) ? twofer.__defaults__.z : arguments[2]);
    var RS_kwargs_obj = arguments[arguments.length["-"](1)];
    if ((((RS_kwargs_obj === null) || (typeof RS_kwargs_obj !== "object")) || (RS_kwargs_obj[RS_kwargs_symbol] !== true))) { RS_kwargs_obj = { }; };
    if (Object.prototype.hasOwnProperty.call(RS_kwargs_obj, "x")) {
      x = RS_kwargs_obj.x; } ;

    if (Object.prototype.hasOwnProperty.call(RS_kwargs_obj, "y")) {
      y = RS_kwargs_obj.y; } ;

    if (Object.prototype.hasOwnProperty.call(RS_kwargs_obj, "z")) {
      z = RS_kwargs_obj.z; } ;

    var RS_ls, keys, k, values;
    "229";
    "231";
    if ((((x === "") || ((typeof x === "object") && RS_equals(x, ""))))) {
      "232";
      if (!twoferDict) {
        return RS_dict(); } ;

      "234";
      keys = (function() {
        var RS_Iter = RS_Iterable(twoferDict.keys()), RS_Result = [], k;
        for (var RS_Index = 0; RS_Index["<"](RS_Iter.length); RS_Index++) {
          k = RS_Iter[RS_Index];
          RS_Result.push(eval(k)); };

        RS_Result = RS_list_constructor(RS_Result);
        return RS_Result;
      })();
      "235";
      values = twoferDict.values();
      "236";
      return list(zip(keys, values)); } ;

    "239";
    if ((((x === "keys") || ((typeof x === "object") && RS_equals(x, "keys"))))) {
      "240";
      return (function() {
        var RS_Iter = RS_Iterable(twoferDict.keys()), RS_Result = [], k;
        for (var RS_Index = 0; RS_Index["<"](RS_Iter.length); RS_Index++) {
          k = RS_Iter[RS_Index];
          RS_Result.push(eval(k)); };

        RS_Result = RS_list_constructor(RS_Result);
        return RS_Result;
      })(); } ;

    "242";
    if ((((x === "values") || ((typeof x === "object") && RS_equals(x, "values"))))) {
      "243";
      return list(twoferDict.values()); } ;

    "245";
    if ((((x === "items") || ((typeof x === "object") && RS_equals(x, "items"))))) {
      "246";
      keys = (function() {
        var RS_Iter = RS_Iterable(twoferDict.keys()), RS_Result = [], k;
        for (var RS_Index = 0; RS_Index["<"](RS_Iter.length); RS_Index++) {
          k = RS_Iter[RS_Index];
          RS_Result.push(eval(k)); };

        RS_Result = RS_list_constructor(RS_Result);
        return RS_Result;
      })();
      "247";
      return list(zip(keys, twoferDict.values())); } ;

    "249";
    if ((((z !== "") && (((typeof z !== "object") || RS_not_equals(z, "")))))) {
      "250";
      RS_setitem(twoferDict, str([x,y,]), z);
      "251";
      return z;
      "252"; }
     else {
      "253";
      if (RS_in(str([x,y,]), twoferDict)) {
        "254";
        return RS_getitem(twoferDict, str([x,y,]));
        "255"; }
       else {
        "256";
        throw new KeyError(str([x,y,])); } ; } ; }; var __frame = { name: "main", line: 33 }; return __func(_, this, arguments, main, 0, __frame, function __$main() { version = RS_list_decorate(["2.7","glowscript",]); Array.prototype["+"] = function(r) { return this.concat(r); }; Array.prototype["*"] = function(r) { return __array_times_number(this, r); }; __name__ = "__main__"; window.__GSlang = "vpython"; box = vp_box; sphere = vp_sphere; cylinder = vp_cylinder; pyramid = vp_pyramid; cone = vp_cone; helix = vp_helix; ellipsoid = vp_ellipsoid; ring = vp_ring; arrow = vp_arrow; compound = vp_compound; display = canvas; vector = vec; print = GSprint; scene = canvas(); strings = RS_modules.pythonize.strings; strings(); "2"; if (!GlowMe.__defaults__) { Object.defineProperties(GlowMe, { __defaults__: { value: { me: "" } }, __handles_kwarg_interpolation__: { value: true }, __argnames__: { value: ["me",] } }); } ; "4"; return get_library("http://localhost:8080/lib/jonlib.js", __cb(_, __frame, 42, 4, function __$main() { "7"; scene = canvas(); "8"; V = vector; "10"; DICT.prototype.__init__ = function __init__() { var self = this; var kwargs = arguments[arguments.length["-"](1)]; if ((((kwargs === null) || (typeof kwargs !== "object")) || (kwargs[RS_kwargs_symbol] !== true))) { kwargs = { }; }; var args = Array.prototype.slice.call(arguments, 0); if ((((kwargs !== null) && (typeof kwargs === "object")) && (kwargs[RS_kwargs_symbol] === true))) { args.pop(); }; var RS_ls, obj, keys, values, k, v, i, d, RS_unpack, kwarg; "14"; if (RS_equals(len(args), 1)) { "15"; if (RS_equals(type(RS_getitem(args, 0)), type(RS_dict()))) { "17"; obj = RS_getitem(args, 0); "18"; keys = Object.keys(obj); "19"; values = Object.values(obj); "20"; var RS_Iter1 = RS_Iterable(range(len(keys))); for (var RS_Index1 = 0; RS_Index1["<"](RS_Iter1.length); RS_Index1++) { i = RS_Iter1[RS_Index1]; "21"; k = RS_getitem(keys, i); "22"; v = RS_getitem(values, i); "23"; RS_setitem(self, k, v); "25"; }; } else { "26"; if (RS_equals(type(RS_getitem(args, 0)), type(dict()))) { "27"; d = RS_getitem(args, 0); "29"; var RS_Iter2 = RS_Iterable(zip(d.keys(), d.values())); for (var RS_Index2 = 0; RS_Index2["<"](RS_Iter2.length); RS_Index2++) { RS_unpack = RS_Iter2[RS_Index2]; k = RS_unpack[0]; v = RS_unpack[1]; "30"; if (!k.startswith("_")) { "31"; RS_setitem(self, k, v); } ; }; } ; } ; } ; "34"; var RS_Iter3 = RS_Iterable(kwargs); for (var RS_Index3 = 0; RS_Index3["<"](RS_Iter3.length); RS_Index3++) { kwarg = RS_Iter3[RS_Index3]; "35"; RS_setitem(self, kwarg, RS_getitem(kwargs, kwarg)); }; }; if (!DICT.prototype.__init__.__handles_kwarg_interpolation__) { Object.defineProperties(DICT.prototype.__init__, { __handles_kwarg_interpolation__: { value: true } }); } ; DICT.__argnames__ = DICT.prototype.__init__.__argnames__; DICT.__handles_kwarg_interpolation__ = DICT.prototype.__init__.__handles_kwarg_interpolation__; DICT.prototype.keys = function keys() { var self = this; var RS_ls; "38"; return (function() { var RS_Iter = RS_Iterable(Object.keys(self)), RS_Result = [], key; for (var RS_Index = 0; RS_Index["<"](RS_Iter.length); RS_Index++) { key = RS_Iter[RS_Index]; if (!key.startswith("_")) { RS_Result.push(key); } ; }; RS_Result = RS_list_constructor(RS_Result); return RS_Result; })(); }; DICT.prototype.values = function values() { var self = this; var RS_ls, vs, RS_unpack, k, v; "41"; vs = RS_list_decorate([]); "42"; var RS_Iter4 = RS_Iterable(zip(Object.keys(self), Object.values(self))); for (var RS_Index4 = 0; RS_Index4["<"](RS_Iter4.length); RS_Index4++) { RS_unpack = RS_Iter4[RS_Index4]; k = RS_unpack[0]; v = RS_unpack[1]; "43"; if (!k.startswith("_")) { "44"; vs.append(v); } ; }; "45"; return vs; }; DICT.prototype.items = function items() { var self = this; var RS_ls, l, k; "48"; l = RS_list_decorate([]); "49"; var RS_Iter5 = RS_Iterable(self.keys()); for (var RS_Index5 = 0; RS_Index5["<"](RS_Iter5.length); RS_Index5++) { k = RS_Iter5[RS_Index5]; "50"; l.append([k,RS_getitem(self, k),]); }; "51"; return l; }; DICT.prototype.__next__ = function __next__() { var self = this; var RS_ls; "54"; return "next"; }; DICT.prototype.__str__ = function __str__() { var self = this; var RS_ls, pairs, elems, RS_unpack, k, v; "57"; pairs = zip(self.keys(), self.values()); "58"; elems = (function() { var RS_Iter = RS_Iterable(pairs), RS_Result = [], k, v; for (var RS_Index = 0; RS_Index["<"](RS_Iter.length); RS_Index++) { RS_unpack = RS_Iter[RS_Index]; k = RS_unpack[0]; v = RS_unpack[1]; if (!k.startswith("_")) { RS_Result.push(str(k)["+"](":")["+"](str(v))); } ; }; RS_Result = RS_list_constructor(RS_Result); return RS_Result; })(); "59"; elems = str(elems); "60"; elems = elems.replace("[", "{").replace("]", "}"); "61"; while (RS_in("\"", elems)) { "62"; elems = elems.replace("\"", ""); }; "63"; return "DO:"["+"](elems); }; DICT.prototype.__repr__ = function __repr__() { return "<"["+"](__name__)["+"](".")["+"](this.constructor.name)["+"](" #")["+"](this.RS_object_id)["+"](">"); }; Object.defineProperty(DICT.prototype, "__bases__", { value: [] }); DICT.prototype.RS_ls = "11"; DICT.prototype.RS_ls = "37"; DICT.prototype.RS_ls = "40"; DICT.prototype.RS_ls = "47"; DICT.prototype.RS_ls = "53"; DICT.prototype.RS_ls = "56"; "68"; if (!_hooke.__argnames__) { Object.defineProperties(_hooke, { __argnames__: { value: ["n1","n2","k","r",] } }); } ; "92"; if (!_constrain.__argnames__) { Object.defineProperties(_constrain, { __argnames__: { value: ["value","min_value","max_value",] } }); } ; "97"; if (!vFromLoc.__argnames__) { Object.defineProperties(vFromLoc, { __argnames__: { value: ["loc",] } }); } ; "103"; if (!nodesFromEdges.__argnames__) { Object.defineProperties(nodesFromEdges, { __argnames__: { value: ["edges",] } }); } ; "113"; if (!generate.__argnames__) { Object.defineProperties(generate, { __argnames__: { value: ["edges","_",] } }); } ; "222"; data = edges = RS_list_decorate([[1,2,],[2,3,],[3,1,],[2,4,],[2,5,],]); "223"; spheres = new DICT; "224"; labels = new DICT; "226"; twoferDict = new DICT; "227";      if (!twofer.__defaults__) { Object.defineProperties(twofer, {
          __defaults__: { value: { x: "", y: "", z: "" } },
          __handles_kwarg_interpolation__: { value: true },
          __argnames__: { value: ["x","y","z",] } }); } ;


      "259";
      curves = twofer;
      "262";
      nodes = nodesFromEdges(data);
      "263";
      RS_Iter19 = RS_Iterable(nodes);
      for (RS_Index19 = 0; RS_Index19["<"](RS_Iter19.length); RS_Index19++) {
        node = RS_Iter19[RS_Index19];
        "264";
        s = sphere();
        "265";
        RS_setitem(spheres, node, s);
        "266";
        l = RS_interpolate_kwargs.call(__this, label, [RS_desugar_kwargs({ text: str(node) }),]);
        "267";
        l.pos = s.pos;
        "268";
        RS_setitem(labels, node, l); };

      "270";
      RS_Iter20 = RS_Iterable(edges);
      for (RS_Index20 = 0; RS_Index20["<"](RS_Iter20.length); RS_Index20++) {
        edge = RS_Iter20[RS_Index20];
        "271";
        RS_unpack = edge;
        RS_unpack = RS_unpack_asarray(2, RS_unpack);
        s = RS_unpack[0];
        t = RS_unpack[1];
        "272";
        spos = RS_getitem(spheres, s).pos;
        "273";
        tpos = RS_getitem(spheres, t).pos;
        "274";
        curves(s, t, RS_interpolate_kwargs.call(__this, curve, [RS_desugar_kwargs({ pos: RS_list_decorate([spos,tpos,]) }),])); };

      "276";
      return generate(data, __cb(_, __frame, 780, 4, function __$main() {
        "277";
        print("Saturday 2/25/18; works"); ; }, true)); }, true)); });};

if (!main.__argnames__) { Object.defineProperties(main, {
    __argnames__: { value: ["_",] } });};

;$(function(){ window.__context = { glowscript_container: $("#glowscript").removeAttr("id") }; main(__func) })})()
